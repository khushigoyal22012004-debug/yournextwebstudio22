import { contact } from '@/lib/site'
import { SiteButton } from './site-button'
import { Reveal } from './reveal'
import { WhatsAppIcon } from './brand-icons'

type CTASectionProps = {
  eyebrow: string
  title: React.ReactNode
  buttonLabel: string
}

export function CTASection({ eyebrow, title, buttonLabel }: CTASectionProps) {
  return (
    <section className="px-5 py-20 sm:px-8 lg:py-28">
      <Reveal className="relative mx-auto max-w-7xl overflow-hidden rounded-[2rem] border border-white/[0.08] bg-[#111111] px-6 py-16 sm:px-12 lg:px-20 lg:py-24">
        <div aria-hidden="true" className="bg-grid absolute inset-0 opacity-60" />
        <div
          aria-hidden="true"
          className="absolute -bottom-40 left-1/2 size-[520px] -translate-x-1/2 rounded-full bg-primary/25 blur-[120px]"
        />
        <div className="relative flex flex-col items-center gap-8 text-center">
          <p className="rounded-full border border-white/10 bg-white/[0.04] px-4 py-1.5 text-sm font-medium text-muted-foreground">
            {eyebrow}
          </p>
          <h2 className="max-w-4xl text-4xl font-bold leading-[1.05] tracking-tight text-foreground sm:text-5xl lg:text-7xl">
            {title}
          </h2>
          <div className="flex w-full flex-col items-center justify-center gap-3 sm:w-auto sm:flex-row">
            <SiteButton href="/contact" className="w-full sm:w-auto">
              {buttonLabel}
            </SiteButton>
            <SiteButton
              href={contact.whatsappHref}
              variant="outline"
              showArrow={false}
              icon={<WhatsAppIcon className="size-4 text-primary" />}
              className="w-full sm:w-auto"
            >
              WhatsApp Us
            </SiteButton>
          </div>
        </div>
      </Reveal>
    </section>
  )
}
