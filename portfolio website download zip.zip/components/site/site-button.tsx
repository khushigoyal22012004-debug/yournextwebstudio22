import Link from 'next/link'
import { ArrowUpRight } from 'lucide-react'
import { cn } from '@/lib/utils'

type Variant = 'primary' | 'outline' | 'ghost'

type SiteButtonProps = {
  href: string
  children: React.ReactNode
  variant?: Variant
  external?: boolean
  showArrow?: boolean
  icon?: React.ReactNode
  className?: string
  ariaLabel?: string
  onClick?: () => void
}

const variants: Record<Variant, string> = {
  primary:
    'bg-primary text-primary-foreground hover:bg-[#ffb133] shadow-[0_0_0_0_rgba(255,157,0,0)] hover:shadow-[0_10px_40px_-10px_rgba(255,157,0,0.6)]',
  outline: 'border border-white/15 bg-white/[0.03] text-foreground hover:border-primary/60 hover:bg-white/[0.06]',
  ghost: 'text-foreground/80 hover:text-primary',
}

export function SiteButton({
  href,
  children,
  variant = 'primary',
  external,
  showArrow = true,
  icon,
  className,
  ariaLabel,
  onClick,
}: SiteButtonProps) {
  const classes = cn(
    'group inline-flex items-center justify-center gap-2 rounded-full px-6 py-3.5 text-sm font-semibold transition-all duration-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background',
    variants[variant],
    className,
  )

  const content = (
    <>
      {icon}
      <span>{children}</span>
      {showArrow && (
        <ArrowUpRight
          aria-hidden="true"
          className="size-4 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5"
        />
      )}
    </>
  )

  if (external || /^(https?:|mailto:|tel:)/.test(href)) {
    const isWeb = href.startsWith('http')
    return (
      <a
        href={href}
        className={classes}
        aria-label={ariaLabel}
        onClick={onClick}
        {...(isWeb ? { target: '_blank', rel: 'noopener noreferrer' } : {})}
      >
        {content}
      </a>
    )
  }

  return (
    <Link href={href} className={classes} aria-label={ariaLabel} onClick={onClick}>
      {content}
    </Link>
  )
}
