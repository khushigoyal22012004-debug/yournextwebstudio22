import { cn } from '@/lib/utils'
import { Reveal } from './reveal'

type SectionHeadingProps = {
  eyebrow?: string
  title: React.ReactNode
  description?: React.ReactNode
  align?: 'left' | 'center'
  as?: 'h1' | 'h2'
  className?: string
  action?: React.ReactNode
}

export function Eyebrow({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <p
      className={cn(
        'inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.22em] text-primary',
        className,
      )}
    >
      <span className="size-1.5 rounded-full bg-primary" aria-hidden="true" />
      {children}
    </p>
  )
}

export function SectionHeading({
  eyebrow,
  title,
  description,
  align = 'left',
  as: Tag = 'h2',
  className,
  action,
}: SectionHeadingProps) {
  return (
    <Reveal
      className={cn(
        'flex flex-col gap-6',
        align === 'center' ? 'items-center text-center' : 'md:flex-row md:items-end md:justify-between',
        className,
      )}
    >
      <div className={cn('flex flex-col gap-4', align === 'center' ? 'items-center max-w-3xl' : 'max-w-2xl')}>
        {eyebrow && <Eyebrow>{eyebrow}</Eyebrow>}
        <Tag
          className={cn(
            'font-bold tracking-tight text-foreground',
            Tag === 'h1'
              ? 'text-4xl leading-[1.05] sm:text-5xl lg:text-7xl'
              : 'text-3xl leading-[1.1] sm:text-4xl lg:text-5xl',
          )}
        >
          {title}
        </Tag>
        {description && <p className="text-base leading-relaxed text-muted-foreground sm:text-lg">{description}</p>}
      </div>
      {action && <div className="shrink-0">{action}</div>}
    </Reveal>
  )
}
