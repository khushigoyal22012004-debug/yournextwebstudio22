import { Asterisk } from 'lucide-react'

const items = [
  'Landing Pages',
  'Business Websites',
  'Shopify Stores',
  'WordPress',
  'Portfolio Sites',
  'Product Ads',
  'CGI Ads',
  'Product Videos',
  'UGC Content',
]

export function Marquee() {
  return (
    <div className="relative overflow-hidden border-y border-white/[0.06] bg-[#0e0e0e] py-6" aria-label="Services we offer">
      <div className="pointer-events-none absolute inset-y-0 left-0 z-10 w-24 bg-gradient-to-r from-[#0e0e0e] to-transparent" />
      <div className="pointer-events-none absolute inset-y-0 right-0 z-10 w-24 bg-gradient-to-l from-[#0e0e0e] to-transparent" />
      <div className="animate-marquee flex w-max items-center hover:[animation-play-state:paused]">
        {[0, 1].map((dup) => (
          <ul key={dup} className="flex shrink-0 items-center" aria-hidden={dup === 1}>
            {items.map((item) => (
              <li key={item} className="flex items-center gap-6 px-6">
                <span className="whitespace-nowrap font-display text-2xl font-bold tracking-tight text-foreground/90 sm:text-3xl">
                  {item}
                </span>
                <Asterisk className="size-6 text-primary" aria-hidden="true" />
              </li>
            ))}
          </ul>
        ))}
      </div>
    </div>
  )
}
