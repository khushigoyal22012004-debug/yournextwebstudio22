'use client'

import { useState } from 'react'
import { CheckCircle2, Loader2, Send } from 'lucide-react'
import { cn } from '@/lib/utils'
import { sendEnquiry } from '@/app/actions/send-enquiry'
import { contact } from '@/lib/site'

const serviceOptions = [
  'Landing Page',
  'Business Website',
  'Shopify E-commerce',
  'WordPress Website',
  'Portfolio Website',
  'Product Ads',
  'CGI Ads',
  'Product Video',
  'UGC Content',
  'Other',
]

type FormValues = {
  name: string
  email: string
  phone: string
  brand: string
  service: string
  details: string
}

type Errors = Partial<Record<keyof FormValues, string>>

const initialValues: FormValues = { name: '', email: '', phone: '', brand: '', service: '', details: '' }

function validate(values: FormValues): Errors {
  const errors: Errors = {}
  if (values.name.trim().length < 2) errors.name = 'Please enter your full name.'
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(values.email.trim())) errors.email = 'Please enter a valid email address.'
  const digits = values.phone.replace(/[^\d]/g, '')
  if (digits.length < 10 || digits.length > 13) errors.phone = 'Please enter a valid phone number.'
  if (!values.service) errors.service = 'Please choose a service.'
  if (values.details.trim().length < 15) errors.details = 'Tell us a little more about your project (at least 15 characters).'
  return errors
}

const fieldBase =
  'w-full rounded-2xl border bg-white/[0.03] px-4 py-3.5 text-[15px] text-foreground placeholder:text-muted-foreground/60 transition-colors focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary/60'

export function ContactForm() {
  const [values, setValues] = useState<FormValues>(initialValues)
  const [errors, setErrors] = useState<Errors>({})
  const [submitted, setSubmitted] = useState(false)
  const [submittedName, setSubmittedName] = useState('')
  const [sending, setSending] = useState(false)
  const [submitError, setSubmitError] = useState('')

  const update = (key: keyof FormValues) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const value = e.target.value
    setValues((v) => ({ ...v, [key]: value }))
    if (errors[key]) setErrors((err) => ({ ...err, [key]: undefined }))
  }

  const onSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    if (sending) return
    const result = validate(values)
    setErrors(result)
    setSubmitError('')
    if (Object.keys(result).length > 0) {
      const first = Object.keys(result)[0]
      document.getElementById(`field-${first}`)?.focus()
      return
    }
    setSending(true)
    const response = await sendEnquiry(values)
    setSending(false)
    if (!response.ok) {
      setSubmitError(response.error)
      return
    }
    setSubmittedName(values.name.trim().split(' ')[0])
    setSubmitted(true)
    setValues(initialValues)
  }

  if (submitted) {
    return (
      <div
        role="status"
        className="flex flex-col items-start gap-6 rounded-3xl border border-primary/30 bg-primary/[0.06] p-8 sm:p-10"
      >
        <span className="flex size-14 items-center justify-center rounded-2xl bg-primary text-primary-foreground">
          <CheckCircle2 className="size-7" aria-hidden="true" />
        </span>
        <div className="flex flex-col gap-3">
          <h3 className="text-2xl font-bold tracking-tight text-foreground sm:text-3xl">
            Thank you, {submittedName}! Your enquiry is in.
          </h3>
          <p className="leading-relaxed text-muted-foreground">
            {"We've received your project details and will get back to you shortly. For a faster response, feel free to message us on WhatsApp."}
          </p>
        </div>
        <div className="flex flex-wrap gap-3">
          <a
            href={contact.whatsappHref}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 rounded-full bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground transition-colors hover:bg-[#ffb133]"
          >
            Chat on WhatsApp
          </a>
          <button
            type="button"
            onClick={() => setSubmitted(false)}
            className="inline-flex items-center gap-2 rounded-full border border-white/15 px-6 py-3 text-sm font-semibold text-foreground transition-colors hover:border-primary/60"
          >
            Send another enquiry
          </button>
        </div>
      </div>
    )
  }

  const field = (key: keyof FormValues) => ({
    id: `field-${key}`,
    name: key,
    value: values[key],
    onChange: update(key),
    'aria-invalid': errors[key] ? true : undefined,
    'aria-describedby': errors[key] ? `error-${key}` : undefined,
    className: cn(fieldBase, errors[key] ? 'border-destructive/70' : 'border-white/10'),
  })

  const ErrorText = ({ k }: { k: keyof FormValues }) =>
    errors[k] ? (
      <p id={`error-${k}`} className="text-sm text-destructive">
        {errors[k]}
      </p>
    ) : null

  const Label = ({ k, children, optional }: { k: keyof FormValues; children: React.ReactNode; optional?: boolean }) => (
    <label htmlFor={`field-${k}`} className="text-sm font-medium text-foreground">
      {children}
      {optional ? (
        <span className="ml-1 text-muted-foreground">(optional)</span>
      ) : (
        <span className="ml-0.5 text-primary" aria-hidden="true">
          *
        </span>
      )}
    </label>
  )

  return (
    <form
      onSubmit={onSubmit}
      noValidate
      className="flex flex-col gap-5 rounded-3xl border border-white/[0.07] bg-card p-6 sm:p-8"
      aria-label="Project enquiry form"
    >
      <div className="grid gap-5 sm:grid-cols-2">
        <div className="flex flex-col gap-2">
          <Label k="name">Full Name</Label>
          <input type="text" autoComplete="name" placeholder="Your full name" {...field('name')} />
          <ErrorText k="name" />
        </div>
        <div className="flex flex-col gap-2">
          <Label k="email">Email Address</Label>
          <input type="email" autoComplete="email" placeholder="you@company.com" {...field('email')} />
          <ErrorText k="email" />
        </div>
        <div className="flex flex-col gap-2">
          <Label k="phone">Phone Number</Label>
          <input type="tel" autoComplete="tel" inputMode="tel" placeholder="+91 98765 43210" {...field('phone')} />
          <ErrorText k="phone" />
        </div>
        <div className="flex flex-col gap-2">
          <Label k="brand" optional>
            Business / Brand Name
          </Label>
          <input type="text" autoComplete="organization" placeholder="Your business or brand" {...field('brand')} />
        </div>
      </div>

      <div className="flex flex-col gap-2">
        <Label k="service">Service Required</Label>
        <select {...field('service')} className={cn(field('service').className, 'appearance-none bg-[#151515]', !values.service && 'text-muted-foreground/60')}>
          <option value="" disabled>
            Select a service
          </option>
          {serviceOptions.map((s) => (
            <option key={s} value={s} className="text-foreground">
              {s}
            </option>
          ))}
        </select>
        <ErrorText k="service" />
      </div>

      <div className="flex flex-col gap-2">
        <Label k="details">Project Details</Label>
        <textarea
          rows={5}
          placeholder="Tell us about your project, goals, timeline and anything else we should know."
          {...field('details')}
          className={cn(field('details').className, 'resize-y')}
        />
        <ErrorText k="details" />
      </div>

      {submitError ? (
        <p role="alert" className="rounded-2xl border border-destructive/40 bg-destructive/10 px-4 py-3 text-sm text-destructive">
          {submitError}
        </p>
      ) : null}

      <button
        type="submit"
        disabled={sending}
        aria-busy={sending}
        className="group mt-2 inline-flex items-center justify-center gap-2 rounded-full bg-primary px-6 py-4 text-sm font-semibold text-primary-foreground transition-all duration-300 hover:bg-[#ffb133] hover:shadow-[0_10px_40px_-10px_rgba(255,157,0,0.6)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:cursor-not-allowed disabled:opacity-70"
      >
        {sending ? 'Sending...' : 'Send Project Enquiry'}
        {sending ? (
          <Loader2 className="size-4 animate-spin" aria-hidden="true" />
        ) : (
          <Send className="size-4 transition-transform duration-300 group-hover:translate-x-0.5" aria-hidden="true" />
        )}
      </button>
    </form>
  )
}
