import Link from 'next/link'
import { ArrowUpRight } from 'lucide-react'
import type { Service } from '@/lib/site'

export function ServiceCard({ service }: { service: Service }) {
  const Icon = service.icon
  return (
    <Link
      href={`/services#${service.id}`}
      className="group relative flex h-full flex-col justify-between gap-10 overflow-hidden rounded-3xl border border-white/[0.07] bg-card p-6 transition-all duration-500 hover:-translate-y-1 hover:border-primary/40 hover:shadow-[0_20px_60px_-25px_rgba(255,157,0,0.45)] sm:p-7"
    >
      <span
        aria-hidden="true"
        className="pointer-events-none absolute -right-16 -top-16 size-40 rounded-full bg-primary/0 blur-3xl transition-colors duration-500 group-hover:bg-primary/20"
      />
      <div className="flex items-start justify-between">
        <span className="flex size-12 items-center justify-center rounded-2xl border border-white/10 bg-white/[0.03] text-primary transition-colors duration-300 group-hover:bg-primary group-hover:text-primary-foreground">
          <Icon className="size-5" aria-hidden="true" />
        </span>
        <span className="font-display text-sm font-semibold text-muted-foreground">{service.number}</span>
      </div>
      <div className="flex flex-col gap-3">
        <h3 className="text-xl font-bold tracking-tight text-foreground">{service.shortTitle}</h3>
        <p className="text-sm leading-relaxed text-muted-foreground">{service.short}</p>
        <span className="mt-3 inline-flex items-center gap-2 text-sm font-semibold text-foreground">
          Learn more
          <span className="flex size-8 items-center justify-center rounded-full border border-white/10 transition-all duration-300 group-hover:border-primary group-hover:bg-primary group-hover:text-primary-foreground">
            <ArrowUpRight
              className="size-4 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5"
              aria-hidden="true"
            />
          </span>
        </span>
      </div>
    </Link>
  )
}
