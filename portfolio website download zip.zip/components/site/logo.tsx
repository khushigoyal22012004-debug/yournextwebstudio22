import Link from 'next/link'

export function Logo({ onClick }: { onClick?: () => void }) {
  return (
    <Link
      href="/"
      onClick={onClick}
      className="group flex items-center gap-2.5"
      aria-label="Your Next Web Studio — Home"
    >
      <span className="flex size-9 items-center justify-center rounded-xl bg-primary font-display text-sm font-extrabold text-primary-foreground transition-transform duration-300 group-hover:rotate-[-6deg]">
        YN
      </span>
      <span className="flex flex-col leading-none">
        <span className="font-display text-[15px] font-bold tracking-tight text-foreground">Your Next</span>
        <span className="text-[11px] font-medium uppercase tracking-[0.2em] text-[#f1ece0]">Web Studio</span>
      </span>
    </Link>
  )
}
