import Image from 'next/image'
import { ArrowRight, ExternalLink } from 'lucide-react'
import type { Project } from '@/lib/site'
import { cn } from '@/lib/utils'

type ProjectCardProps = {
  project: Project
  variant?: 'featured' | 'gallery'
  ctaLabel?: string
  className?: string
}

export function ProjectCard({ project, variant = 'gallery', ctaLabel = 'View Website', className }: ProjectCardProps) {
  const category = variant === 'featured' ? project.featuredCategory : project.category
  const description = variant === 'featured' ? project.featuredDescription : project.description
  const host = new URL(project.url).hostname

  return (
    <article
      className={cn(
        'group relative flex h-full flex-col overflow-hidden rounded-3xl border border-white/[0.07] bg-card p-3 transition-all duration-500 hover:-translate-y-1.5 hover:border-primary/40 hover:shadow-[0_30px_80px_-30px_rgba(255,157,0,0.5)]',
        className,
      )}
    >
      <a
        href={project.url}
        target="_blank"
        rel="noopener noreferrer"
        aria-label={`Open ${project.name} website in a new tab`}
        className="relative block overflow-hidden rounded-2xl border border-white/[0.06] bg-[#0e0e0e]"
      >
        <div className="flex items-center gap-2 border-b border-white/[0.06] bg-[#141414] px-4 py-2.5" aria-hidden="true">
          <span className="size-2.5 rounded-full bg-white/15" />
          <span className="size-2.5 rounded-full bg-white/15" />
          <span className="size-2.5 rounded-full bg-primary/70" />
          <span className="ml-3 truncate rounded-full bg-white/[0.05] px-3 py-1 text-[11px] text-muted-foreground">
            {host}
          </span>
        </div>
        <div className="relative aspect-[1280/633] overflow-hidden">
          <Image
            src={project.image}
            alt={`${project.name} website homepage preview`}
            fill
            sizes="(min-width: 1024px) 40vw, (min-width: 640px) 50vw, 100vw"
            className="object-cover object-top transition-transform duration-700 ease-out group-hover:scale-[1.06]"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent opacity-80" />
          <span className="absolute left-4 top-4 rounded-full bg-black/60 px-3 py-1 font-display text-xs font-semibold text-foreground backdrop-blur">
            {project.number}
          </span>
        </div>
      </a>

      <div className="flex flex-1 flex-col gap-3 px-3 pb-3 pt-6">
        <p className="text-xs font-semibold uppercase tracking-[0.18em] text-primary">{category}</p>
        <h3 className="text-2xl font-bold tracking-tight text-foreground">{project.name}</h3>
        <p className="text-sm leading-relaxed text-muted-foreground">{description}</p>
        <div className="mt-auto flex items-center justify-between pt-4">
          <a
            href={project.url}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 text-sm font-semibold text-foreground transition-colors hover:text-primary"
          >
            {ctaLabel}
            <ArrowRight className="size-4 transition-transform duration-300 group-hover:translate-x-1" aria-hidden="true" />
            <span className="sr-only">(opens {project.name} in a new tab)</span>
          </a>
          <a
            href={project.url}
            target="_blank"
            rel="noopener noreferrer"
            aria-label={`Visit ${project.name} (opens in a new tab)`}
            className="flex size-10 items-center justify-center rounded-full border border-white/10 text-foreground transition-all duration-300 group-hover:border-primary group-hover:bg-primary group-hover:text-primary-foreground"
          >
            <ExternalLink className="size-4" aria-hidden="true" />
          </a>
        </div>
      </div>
    </article>
  )
}
