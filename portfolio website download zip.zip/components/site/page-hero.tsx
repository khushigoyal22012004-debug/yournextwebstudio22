import { Reveal } from './reveal'
import { Eyebrow } from './section-heading'

type PageHeroProps = {
  eyebrow: string
  title: React.ReactNode
  description: string
  children?: React.ReactNode
}

export function PageHero({ eyebrow, title, description, children }: PageHeroProps) {
  return (
    <section className="relative -mt-[72px] overflow-hidden pt-[72px]">
      <div aria-hidden="true" className="bg-grid absolute inset-0 [mask-image:radial-gradient(ellipse_at_top,black_20%,transparent_70%)]" />
      <div aria-hidden="true" className="absolute left-1/2 top-0 size-[480px] -translate-x-1/2 rounded-full bg-primary/10 blur-[140px]" />
      <div className="relative mx-auto flex max-w-7xl flex-col gap-7 px-5 pb-14 pt-16 sm:px-8 lg:pb-20 lg:pt-24">
        <Reveal>
          <Eyebrow>{eyebrow}</Eyebrow>
        </Reveal>
        <Reveal delay={80}>
          <h1 className="max-w-5xl text-4xl font-extrabold leading-[1.04] tracking-tight text-foreground sm:text-6xl lg:text-7xl">
            {title}
          </h1>
        </Reveal>
        <Reveal delay={160}>
          <p className="max-w-2xl text-lg leading-relaxed text-muted-foreground">{description}</p>
        </Reveal>
        {children && <Reveal delay={240}>{children}</Reveal>}
      </div>
    </section>
  )
}
