'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { useEffect, useState } from 'react'
import { Menu, X } from 'lucide-react'
import { cn } from '@/lib/utils'
import { contact, navLinks } from '@/lib/site'
import { SiteButton } from './site-button'
import { Logo } from './logo'
import { InstagramIcon, WhatsAppIcon } from './brand-icons'

export function Navbar() {
  const pathname = usePathname()
  const [open, setOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  useEffect(() => {
    document.body.style.overflow = open ? 'hidden' : ''
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setOpen(false)
    window.addEventListener('keydown', onKey)
    return () => {
      document.body.style.overflow = ''
      window.removeEventListener('keydown', onKey)
    }
  }, [open])

  const isActive = (href: string) => (href === '/' ? pathname === '/' : pathname.startsWith(href))
  const close = () => setOpen(false)

  return (
    <header
      className={cn(
        'sticky top-0 z-50 w-full transition-all duration-300',
        scrolled || open
          ? 'border-b border-white/[0.06] bg-background/80 backdrop-blur-xl'
          : 'border-b border-transparent bg-transparent',
      )}
    >
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:rounded-full focus:bg-primary focus:px-4 focus:py-2 focus:text-primary-foreground"
      >
        Skip to content
      </a>
      <nav aria-label="Main" className="mx-auto flex h-[72px] max-w-7xl items-center justify-between px-5 sm:px-8">
        <Logo onClick={close} />

        <ul className="hidden items-center gap-1 rounded-full border border-white/[0.08] bg-white/[0.03] p-1 md:flex">
          {navLinks.map((link) => {
            const active = isActive(link.href)
            return (
              <li key={link.href}>
                <Link
                  href={link.href}
                  aria-current={active ? 'page' : undefined}
                  className={cn(
                    'relative flex items-center gap-2 rounded-full px-4 py-2 text-sm font-medium transition-colors',
                    active ? 'bg-white/[0.07] text-foreground' : 'text-muted-foreground hover:text-foreground',
                  )}
                >
                  {active && <span className="size-1.5 rounded-full bg-primary" aria-hidden="true" />}
                  {link.label}
                </Link>
              </li>
            )
          })}
        </ul>

        <div className="hidden md:block">
          <SiteButton href="/contact" className="px-5 py-2.5">
            {"Let's Talk"}
          </SiteButton>
        </div>

        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          aria-expanded={open}
          aria-controls="mobile-menu"
          aria-label={open ? 'Close menu' : 'Open menu'}
          className="inline-flex size-11 items-center justify-center rounded-full border border-white/10 bg-white/[0.04] text-foreground transition-colors hover:border-primary/60 md:hidden"
        >
          {open ? <X className="size-5" aria-hidden="true" /> : <Menu className="size-5" aria-hidden="true" />}
        </button>
      </nav>

      <div
        id="mobile-menu"
        className={cn(
          'fixed inset-x-0 top-[72px] bottom-0 z-40 overflow-y-auto bg-background/95 backdrop-blur-xl transition-all duration-300 md:hidden',
          open ? 'visible translate-y-0 opacity-100' : 'invisible -translate-y-3 opacity-0',
        )}
        aria-hidden={!open}
        inert={!open}
      >
        <div className="flex min-h-full flex-col justify-between px-5 pb-10 pt-6">
          <ul className="flex flex-col">
            {navLinks.map((link, i) => {
              const active = isActive(link.href)
              return (
                <li key={link.href} className="border-b border-white/[0.06]">
                  <Link
                    href={link.href}
                    onClick={close}
                    aria-current={active ? 'page' : undefined}
                    className="flex items-center justify-between py-5 font-display text-3xl font-bold tracking-tight"
                  >
                    <span className={active ? 'text-primary' : 'text-foreground'}>{link.label}</span>
                    <span className="text-sm font-medium text-muted-foreground">0{i + 1}</span>
                  </Link>
                </li>
              )
            })}
          </ul>
          <div className="mt-10 flex flex-col gap-4">
            <SiteButton href="/contact" onClick={close} className="w-full">
              {"Let's Talk"}
            </SiteButton>
            <div className="flex gap-3">
              <SiteButton
                href={contact.whatsappHref}
                variant="outline"
                showArrow={false}
                icon={<WhatsAppIcon className="size-4" />}
                className="flex-1"
              >
                WhatsApp
              </SiteButton>
              <SiteButton
                href={contact.instagramHref}
                variant="outline"
                showArrow={false}
                icon={<InstagramIcon className="size-4" />}
                className="flex-1"
              >
                Instagram
              </SiteButton>
            </div>
          </div>
        </div>
      </div>
    </header>
  )
}
