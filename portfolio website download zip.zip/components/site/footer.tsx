import Link from 'next/link'
import { contact, navLinks, services } from '@/lib/site'
import { Logo } from './logo'
import { InstagramIcon, WhatsAppIcon } from './brand-icons'

const footerServices = services.slice(0, 8)

const connectLinks = [
  { label: 'Phone', value: contact.phoneDisplay, href: contact.phoneHref },
  { label: 'Email', value: contact.email, href: contact.emailHref },
  { label: 'Instagram', value: contact.instagramHandle, href: contact.instagramHref },
  { label: 'WhatsApp', value: 'Chat with us', href: contact.whatsappHref },
]

export function Footer() {
  return (
    <footer className="relative overflow-hidden border-t border-white/[0.06] bg-[#080808]">
      <div className="mx-auto max-w-7xl px-5 pb-10 pt-16 sm:px-8 lg:pt-20">
        <div className="grid gap-12 lg:grid-cols-12">
          <div className="flex flex-col gap-6 lg:col-span-4">
            <Logo />
            <p className="max-w-sm text-sm leading-relaxed text-muted-foreground">
              Modern websites and creative digital experiences for businesses ready to grow online.
            </p>
            <div className="flex gap-3">
              <a
                href={contact.instagramHref}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Instagram"
                className="flex size-11 items-center justify-center rounded-full border border-white/10 text-foreground transition-colors hover:border-primary hover:text-primary"
              >
                <InstagramIcon className="size-5" />
              </a>
              <a
                href={contact.whatsappHref}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="WhatsApp"
                className="flex size-11 items-center justify-center rounded-full border border-white/10 text-foreground transition-colors hover:border-primary hover:text-primary"
              >
                <WhatsAppIcon className="size-5" />
              </a>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-10 sm:grid-cols-3 lg:col-span-8">
            <div>
              <h2 className="mb-5 text-xs font-semibold uppercase tracking-[0.2em] text-primary">Company</h2>
              <ul className="flex flex-col gap-3">
                {navLinks.map((link) => (
                  <li key={link.href}>
                    <Link href={link.href} className="text-sm text-muted-foreground transition-colors hover:text-foreground">
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h2 className="mb-5 text-xs font-semibold uppercase tracking-[0.2em] text-primary">Services</h2>
              <ul className="flex flex-col gap-3">
                {footerServices.map((s) => (
                  <li key={s.id}>
                    <Link
                      href={`/services#${s.id}`}
                      className="text-sm text-muted-foreground transition-colors hover:text-foreground"
                    >
                      {s.shortTitle.replace(' E-commerce', '')}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
            <div className="col-span-2 sm:col-span-1">
              <h2 className="mb-5 text-xs font-semibold uppercase tracking-[0.2em] text-primary">Connect</h2>
              <ul className="flex flex-col gap-4">
                {connectLinks.map((c) => (
                  <li key={c.label}>
                    <a
                      href={c.href}
                      {...(c.href.startsWith('http') ? { target: '_blank', rel: 'noopener noreferrer' } : {})}
                      className="group flex flex-col"
                    >
                      <span className="text-xs text-muted-foreground">{c.label}</span>
                      <span className="break-all text-sm text-foreground transition-colors group-hover:text-primary">
                        {c.value}
                      </span>
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        <div className="mt-16 flex flex-col gap-3 border-t border-white/[0.06] pt-6 text-xs text-muted-foreground sm:flex-row sm:items-center sm:justify-between">
          <p>&copy; 2026 Your Next Web Studio. All Rights Reserved.</p>
          <p>Websites &middot; E-commerce &middot; Creative Ads</p>
        </div>
      </div>
    </footer>
  )
}
