import { services } from '@/lib/site'
import { SectionHeading } from '@/components/site/section-heading'
import { ServiceCard } from '@/components/site/service-card'
import { SiteButton } from '@/components/site/site-button'
import { Reveal } from '@/components/site/reveal'

export function ServicesPreview() {
  return (
    <section className="bg-surface py-20 lg:py-28">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <SectionHeading
          eyebrow="Services"
          title="What We Create"
          description="Websites, stores and scroll-stopping creative content — designed to make your brand look sharp everywhere it shows up."
          action={
            <SiteButton href="/services" variant="outline">
              Explore Services
            </SiteButton>
          }
        />
        <ul className="mt-14 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {services.slice(0, 8).map((service, i) => (
            <Reveal as="li" key={service.id} delay={(i % 4) * 80}>
              <ServiceCard service={service} />
            </Reveal>
          ))}
        </ul>
      </div>
    </section>
  )
}
