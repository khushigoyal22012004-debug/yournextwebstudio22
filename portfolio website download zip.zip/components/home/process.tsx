import { SectionHeading } from '@/components/site/section-heading'
import { Reveal } from '@/components/site/reveal'

const steps = [
  { number: '01', title: 'Discover', text: 'Understand the business, audience and goals.' },
  { number: '02', title: 'Plan', text: 'Structure the website, content and user journey.' },
  { number: '03', title: 'Design', text: 'Create the visual direction, UI and responsive layouts.' },
  { number: '04', title: 'Deliver', text: 'Refine, test and prepare the final digital experience.' },
]

export function Process() {
  return (
    <section className="bg-surface py-20 lg:py-28">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <SectionHeading eyebrow="Process" title="How We Turn Ideas Into Digital Experiences" />
        <ol className="relative mt-16 grid gap-10 border-l border-white/10 pl-8 md:grid-cols-4 md:gap-6 md:border-l-0 md:border-t md:pl-0 md:pt-12">
          {steps.map((step, i) => (
            <Reveal as="li" key={step.number} delay={i * 120} className="relative">
              <span
                aria-hidden="true"
                className="absolute -left-[39px] top-1 flex size-4 items-center justify-center rounded-full border-2 border-primary bg-background md:-top-[57px] md:left-0"
              >
                <span className="size-1.5 rounded-full bg-primary" />
              </span>
              <div className="flex flex-col gap-3">
                <span className="font-display text-sm font-semibold text-primary">{step.number}</span>
                <h3 className="text-2xl font-bold uppercase tracking-tight text-foreground">{step.title}</h3>
                <p className="max-w-xs leading-relaxed text-muted-foreground">{step.text}</p>
              </div>
            </Reveal>
          ))}
        </ol>
      </div>
    </section>
  )
}
