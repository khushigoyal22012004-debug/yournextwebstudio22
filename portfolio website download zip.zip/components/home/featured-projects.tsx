import { projects } from '@/lib/site'
import { SectionHeading } from '@/components/site/section-heading'
import { ProjectCard } from '@/components/site/project-card'
import { SiteButton } from '@/components/site/site-button'
import { Reveal } from '@/components/site/reveal'

export function FeaturedProjects() {
  const featured = projects.filter((p) => p.featured)
  return (
    <section className="mx-auto max-w-7xl px-5 py-20 sm:px-8 lg:py-28">
      <SectionHeading
        eyebrow="Portfolio"
        title="Selected Work"
        description="Explore a few websites created as practice, concept and portfolio projects."
        action={<SiteButton href="/projects">View All Projects</SiteButton>}
      />
      <ul className="mt-14 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
        {featured.map((project, i) => (
          <Reveal as="li" key={project.slug} delay={i * 100}>
            <ProjectCard project={project} variant="featured" ctaLabel="View Project" />
          </Reveal>
        ))}
      </ul>
    </section>
  )
}
