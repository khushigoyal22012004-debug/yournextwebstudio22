import { Compass, MonitorSmartphone, TrendingUp } from 'lucide-react'
import { Reveal } from '@/components/site/reveal'
import { Eyebrow } from '@/components/site/section-heading'

const features = [
  {
    number: '01',
    title: 'Strategic Design',
    text: 'Every design starts with understanding the business, audience and goal.',
    icon: Compass,
  },
  {
    number: '02',
    title: 'Modern Experience',
    text: 'Clean interfaces, responsive layouts and engaging visuals across every screen.',
    icon: MonitorSmartphone,
  },
  {
    number: '03',
    title: 'Business Focused',
    text: 'Websites and creative content designed to support real business goals.',
    icon: TrendingUp,
  },
]

export function Intro() {
  return (
    <section className="mx-auto max-w-7xl px-5 py-20 sm:px-8 lg:py-28">
      <div className="grid gap-10 lg:grid-cols-12">
        <Reveal className="flex flex-col gap-5 lg:col-span-5">
          <Eyebrow>About the studio</Eyebrow>
          <h2 className="text-3xl font-bold leading-[1.1] tracking-tight sm:text-4xl lg:text-5xl">
            Your Digital Presence Deserves <span className="text-primary">More.</span>
          </h2>
        </Reveal>
        <Reveal delay={100} className="lg:col-span-7 lg:pt-10">
          <p className="text-lg leading-relaxed text-muted-foreground sm:text-xl">
            Your Next Web Studio helps businesses turn ideas into polished digital experiences. From business websites and
            Shopify stores to landing pages and product advertising, we combine clean design, strategy and creativity to
            create work that feels professional and purposeful.
          </p>
        </Reveal>
      </div>

      <ul className="mt-14 grid gap-4 md:grid-cols-3">
        {features.map((f, i) => {
          const Icon = f.icon
          return (
            <Reveal as="li" key={f.number} delay={i * 100}>
              <div className="group flex h-full flex-col gap-8 rounded-3xl border border-white/[0.07] bg-card p-7 transition-colors duration-300 hover:border-primary/40">
                <div className="flex items-center justify-between">
                  <span className="font-display text-5xl font-extrabold text-white/10 transition-colors duration-300 group-hover:text-primary/40">
                    {f.number}
                  </span>
                  <Icon className="size-6 text-primary" aria-hidden="true" />
                </div>
                <div className="flex flex-col gap-3">
                  <h3 className="text-sm font-bold uppercase tracking-[0.18em] text-foreground">{f.title}</h3>
                  <p className="leading-relaxed text-muted-foreground">{f.text}</p>
                </div>
              </div>
            </Reveal>
          )
        })}
      </ul>
    </section>
  )
}
