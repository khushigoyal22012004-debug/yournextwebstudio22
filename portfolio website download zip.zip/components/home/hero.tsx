import Image from 'next/image'
import { contact } from '@/lib/site'
import { SiteButton } from '@/components/site/site-button'
import { Eyebrow } from '@/components/site/section-heading'
import { Reveal } from '@/components/site/reveal'
import { WhatsAppIcon } from '@/components/site/brand-icons'

const stats = [
  { value: '9+', label: 'Creative services' },
  { value: '100%', label: 'Responsive builds' },
  { value: '1:1', label: 'Direct collaboration' },
]

export function Hero() {
  return (
    <section className="relative -mt-[72px] overflow-hidden pt-[72px]">
      <div aria-hidden="true" className="bg-grid absolute inset-0 [mask-image:radial-gradient(ellipse_at_top,black_30%,transparent_75%)]" />
      <div
        aria-hidden="true"
        className="absolute right-[-10%] top-[10%] size-[560px] rounded-full bg-primary/15 blur-[140px]"
      />

      <div className="relative mx-auto grid max-w-7xl items-center gap-12 px-5 pb-16 pt-12 sm:px-8 lg:grid-cols-12 lg:gap-8 lg:pb-24 lg:pt-20">
        <div className="flex flex-col gap-8 lg:col-span-7">
          <Reveal>
            <Eyebrow>Your Next Web Studio</Eyebrow>
          </Reveal>
          <Reveal delay={80}>
            <h1 className="text-[2.6rem] font-extrabold leading-[1.02] tracking-tight text-foreground sm:text-6xl lg:text-[4.1rem] xl:text-[4.5rem]">
              Websites & Digital Experiences Built to Move Your{' '}
              <span className="relative whitespace-nowrap text-primary">
                Business Forward.
                <svg
                  aria-hidden="true"
                  viewBox="0 0 300 12"
                  preserveAspectRatio="none"
                  className="absolute -bottom-2 left-0 h-3 w-full text-primary/50"
                >
                  <path d="M2 9C80 3 200 2 298 7" stroke="currentColor" strokeWidth="3" fill="none" strokeLinecap="round" />
                </svg>
              </span>
            </h1>
          </Reveal>
          <Reveal delay={160}>
            <p className="max-w-xl text-lg leading-relaxed text-muted-foreground">
              We design modern websites and creative digital content that help businesses look professional, connect with
              customers and grow online.
            </p>
          </Reveal>
          <Reveal delay={240} className="flex flex-col gap-5">
            <div className="flex flex-col gap-3 sm:flex-row">
              <SiteButton href="/projects">View Our Work</SiteButton>
              <SiteButton href="/contact" variant="outline">
                {"Let's Talk"}
              </SiteButton>
            </div>
            <a
              href={contact.whatsappHref}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex w-fit items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-primary"
            >
              <WhatsAppIcon className="size-4 text-primary" />
              Or message us directly on WhatsApp
            </a>
          </Reveal>
          <Reveal delay={320}>
            <dl className="mt-2 grid max-w-lg grid-cols-3 gap-4 border-t border-white/[0.08] pt-6">
              {stats.map((s) => (
                <div key={s.label} className="flex flex-col gap-1">
                  <dt className="order-2 text-xs text-muted-foreground sm:text-sm">{s.label}</dt>
                  <dd className="order-1 font-display text-2xl font-bold text-foreground sm:text-3xl">{s.value}</dd>
                </div>
              ))}
            </dl>
          </Reveal>
        </div>

        <Reveal delay={200} className="relative lg:col-span-5">
          <div className="animate-float-slow relative mx-auto aspect-square w-full max-w-[520px]">
            <div
              aria-hidden="true"
              className="absolute inset-6 rounded-[2.5rem] border border-white/[0.06] bg-gradient-to-br from-white/[0.04] to-transparent"
            />
            <Image
              src="/hero-visual.png"
              alt="Floating website browser mockups, a phone showing a product ad and a glowing CGI product bottle"
              fill
              priority
              sizes="(min-width: 1024px) 40vw, 90vw"
              className="rounded-[2.5rem] object-cover"
            />
            <div className="absolute -left-2 bottom-10 rounded-2xl border border-white/10 bg-background/80 px-4 py-3 backdrop-blur-md sm:-left-6">
              <p className="text-xs text-muted-foreground">Now booking</p>
              <p className="font-display text-sm font-bold text-foreground">Websites + Creative Ads</p>
            </div>
            <div className="absolute -right-1 top-10 flex items-center gap-2 rounded-full border border-white/10 bg-background/80 px-4 py-2 backdrop-blur-md sm:-right-4">
              <span className="relative flex size-2">
                <span className="absolute inline-flex size-full animate-ping rounded-full bg-primary opacity-75" />
                <span className="relative inline-flex size-2 rounded-full bg-primary" />
              </span>
              <span className="text-xs font-medium text-foreground">Open for projects</span>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  )
}
