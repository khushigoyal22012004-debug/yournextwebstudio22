'use client'

import { useState } from 'react'
import { projectFilters, projects, type ProjectFilter } from '@/lib/site'
import { ProjectCard } from '@/components/site/project-card'
import { cn } from '@/lib/utils'

export function ProjectGallery() {
  const [active, setActive] = useState<ProjectFilter>('All')
  const visible = active === 'All' ? projects : projects.filter((p) => p.tags.includes(active))

  return (
    <div className="flex flex-col gap-10">
      <div role="group" aria-label="Filter projects" className="flex flex-wrap gap-2">
        {projectFilters.map((filter) => {
          const isActive = filter === active
          const count = filter === 'All' ? projects.length : projects.filter((p) => p.tags.includes(filter)).length
          return (
            <button
              key={filter}
              type="button"
              onClick={() => setActive(filter)}
              aria-pressed={isActive}
              className={cn(
                'inline-flex items-center gap-2 rounded-full border px-4 py-2.5 text-sm font-medium transition-all duration-300',
                isActive
                  ? 'border-primary bg-primary text-primary-foreground'
                  : 'border-white/10 bg-white/[0.03] text-muted-foreground hover:border-primary/50 hover:text-foreground',
              )}
            >
              {filter}
              <span
                className={cn(
                  'rounded-full px-1.5 text-xs',
                  isActive ? 'bg-black/15 text-primary-foreground' : 'bg-white/[0.06] text-muted-foreground',
                )}
              >
                {count}
              </span>
            </button>
          )
        })}
      </div>

      <p className="sr-only" aria-live="polite">
        Showing {visible.length} {visible.length === 1 ? 'project' : 'projects'}
      </p>

      <ul className="grid gap-5 md:grid-cols-2">
        {visible.map((project) => (
          <li key={project.slug} className="animate-in fade-in slide-in-from-bottom-4 duration-500">
            <ProjectCard project={project} />
          </li>
        ))}
      </ul>
    </div>
  )
}
