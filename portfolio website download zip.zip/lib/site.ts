import {
  Boxes,
  Briefcase,
  Clapperboard,
  LayoutTemplate,
  type LucideIcon,
  Megaphone,
  PanelsTopLeft,
  ShoppingBag,
  Sparkles,
  UserRound,
} from 'lucide-react'

export const contact = {
  name: 'Your Next Web Studio',
  phoneDisplay: '6266801624',
  phoneHref: 'tel:+916266801624',
  email: 'yournextwebstudio22@gmail.com',
  emailHref: 'mailto:yournextwebstudio22@gmail.com',
  instagramHandle: '@web.agency22',
  instagramHref: 'https://www.instagram.com/web.agency22',
  whatsappHref: 'https://wa.me/916266801624',
}

export const navLinks = [
  { href: '/', label: 'Home' },
  { href: '/services', label: 'Services' },
  { href: '/projects', label: 'Projects' },
  { href: '/contact', label: 'Contact' },
]

export type Service = {
  id: string
  number: string
  title: string
  shortTitle: string
  short: string
  description: string
  features: string[]
  icon: LucideIcon
}

export const services: Service[] = [
  {
    id: 'landing-pages',
    number: '01',
    title: 'Landing Page Design',
    shortTitle: 'Landing Pages',
    short: 'High-converting landing pages designed to turn visitors into enquiries, leads and customers.',
    description:
      'Focused, conversion-friendly landing pages created for campaigns, services, launches and lead generation.',
    features: ['Responsive design', 'Strong CTA structure', 'Modern UI', 'Mobile optimization', 'Lead-focused sections'],
    icon: LayoutTemplate,
  },
  {
    id: 'business-websites',
    number: '02',
    title: 'Business Website',
    shortTitle: 'Business Websites',
    short:
      'Professional websites built to establish credibility, explain your services and help customers connect with your business.',
    description:
      'Professional websites that explain what your business does, build trust and make it easy for customers to take action.',
    features: ['Multi-page structure', 'Service & about sections', 'Enquiry-ready contact flows', 'SEO-friendly foundations', 'Responsive layouts'],
    icon: Briefcase,
  },
  {
    id: 'shopify',
    number: '03',
    title: 'Shopify E-commerce',
    shortTitle: 'Shopify E-commerce',
    short:
      'Modern Shopify stores designed for smooth browsing, strong product presentation and conversion-focused shopping experiences.',
    description:
      'Modern Shopify stores designed for product discovery, smooth navigation and a better online shopping experience.',
    features: ['Product pages', 'Collections', 'Responsive design', 'Conversion-focused layout', 'Store customization'],
    icon: ShoppingBag,
  },
  {
    id: 'wordpress',
    number: '04',
    title: 'WordPress Website',
    shortTitle: 'WordPress Websites',
    short: 'Flexible, professional WordPress websites built around your brand, content and business goals.',
    description: 'Professional WordPress websites tailored around your brand, services and content.',
    features: ['Custom theme styling', 'Easy content editing', 'Blog & pages setup', 'Plugin configuration', 'Responsive design'],
    icon: PanelsTopLeft,
  },
  {
    id: 'portfolio',
    number: '05',
    title: 'Portfolio Website',
    shortTitle: 'Portfolio Websites',
    short: 'Elegant portfolio websites that showcase your work, skills and brand in a memorable way.',
    description:
      'Personal and professional portfolio websites that showcase projects, skills, experience and creative work.',
    features: ['Project showcases', 'Personal branding', 'About & experience', 'Contact integration', 'Smooth animations'],
    icon: UserRound,
  },
  {
    id: 'product-ads',
    number: '06',
    title: 'Product Ads',
    shortTitle: 'Product Ads',
    short: 'Scroll-stopping product creatives designed for social media campaigns, launches and paid advertising.',
    description:
      'Creative product advertising visuals designed to stop the scroll and make products more memorable.',
    features: ['Social media creatives', 'Launch campaign visuals', 'Paid ad formats', 'Brand-consistent design', 'Multiple sizes'],
    icon: Megaphone,
  },
  {
    id: 'cgi-ads',
    number: '07',
    title: 'CGI Ads',
    shortTitle: 'CGI Ads',
    short: 'Eye-catching CGI-style product visuals and advertising concepts designed to make products stand out.',
    description: 'Stylized CGI-inspired product advertising concepts designed for modern digital campaigns.',
    features: ['3D-style product visuals', 'Concept development', 'Stylized environments', 'Campaign-ready output', 'Social formats'],
    icon: Boxes,
  },
  {
    id: 'product-videos',
    number: '08',
    title: 'Product Advertising Videos',
    shortTitle: 'Product Videos',
    short: 'Short-form product videos created for Instagram Reels, ads, launches and digital campaigns.',
    description: 'Short-form product videos for Instagram, Facebook, Reels and digital advertising.',
    features: ['Reels & short-form', 'Motion graphics', 'Product highlights', 'Ad-ready cuts', 'Vertical & square formats'],
    icon: Clapperboard,
  },
  {
    id: 'ugc-content',
    number: '09',
    title: 'UGC / Creative Content',
    shortTitle: 'UGC Content',
    short: 'Natural, engaging product content designed to make brands feel relatable, modern and authentic.',
    description: 'Relatable and engaging product-focused content created for modern social media audiences.',
    features: ['Authentic product content', 'Social-first storytelling', 'Unboxing & demos', 'Lifestyle scenes', 'Platform-native style'],
    icon: Sparkles,
  },
]

export const projectFilters = [
  'All',
  'Business Websites',
  'Landing Pages',
  'E-commerce',
  'Service Websites',
  'Creative Concepts',
] as const

export type ProjectFilter = (typeof projectFilters)[number]

export type Project = {
  slug: string
  number: string
  name: string
  category: string
  featuredCategory: string
  description: string
  featuredDescription: string
  url: string
  image: string
  tags: ProjectFilter[]
  featured: boolean
}

export const projects: Project[] = [
  {
    slug: 'flourish',
    number: '01',
    name: 'Flourish',
    category: 'Furniture Website',
    featuredCategory: 'Furniture / Business Website',
    description:
      'Modern furniture website concept with product categories, featured furniture, showroom content and enquiry-focused sections.',
    featuredDescription:
      'A modern furniture website concept focused on presenting products, collections and enquiries through a clean, premium experience.',
    url: 'https://flourishome22.netlify.app/',
    image: '/projects/flourish.png',
    tags: ['Business Websites', 'E-commerce'],
    featured: true,
  },
  {
    slug: 'homerakshak',
    number: '02',
    name: 'HomeRakshak',
    category: 'Carpenter & Home Woodwork',
    featuredCategory: 'Carpenter / Service Business Website',
    description:
      'Professional local-service website concept presenting carpentry services, custom furniture, repairs and customer contact options.',
    featuredDescription:
      'A professional service website concept created to present carpentry services, build trust and make customer enquiries easier.',
    url: 'https://homerakshak44.netlify.app/',
    image: '/projects/homerakshak.png',
    tags: ['Service Websites', 'Business Websites'],
    featured: true,
  },
  {
    slug: 'exquisite-crostata',
    number: '03',
    name: 'Exquisite Crostata',
    category: 'Website Concept',
    featuredCategory: 'Website Concept',
    description: "Creative website concept developed as part of the studio's practice portfolio.",
    featuredDescription: "Creative website concept developed as part of the studio's practice portfolio.",
    url: 'https://exquisite-crostata-cfe102.netlify.app/',
    image: '/projects/crostata.png',
    tags: ['Creative Concepts', 'Landing Pages'],
    featured: false,
  },
  {
    slug: 'darkslategrey-loris',
    number: '04',
    name: 'Darkslategrey Loris',
    category: 'Website Concept',
    featuredCategory: 'Website Concept',
    description:
      'Creative website concept developed to explore modern web layout, visual hierarchy and responsive design.',
    featuredDescription:
      'Creative website concept developed to explore modern web layout, visual hierarchy and responsive design.',
    url: 'https://darkslategrey-loris-757957.hostingersite.com/',
    image: '/projects/loris.png',
    tags: ['Creative Concepts', 'Landing Pages'],
    featured: false,
  },
  {
    slug: 'estora-realty',
    number: '05',
    name: 'Estora Realty',
    category: 'Real Estate Website',
    featuredCategory: 'Real Estate Website',
    description:
      'Premium real-estate website concept featuring property listings, categories, property discovery and enquiry sections.',
    featuredDescription:
      'A premium real-estate website concept focused on property discovery, featured listings and customer enquiries.',
    url: 'https://refined-residences-pro.lovable.app/',
    image: '/projects/estora.png',
    tags: ['Business Websites', 'Service Websites'],
    featured: true,
  },
]
