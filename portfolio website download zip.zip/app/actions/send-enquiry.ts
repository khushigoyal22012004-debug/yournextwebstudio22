'use server'

import { Resend } from 'resend'

const RECIPIENT = 'yournextwebstudio22@gmail.com'

export type EnquiryInput = {
  name: string
  email: string
  phone: string
  brand: string
  service: string
  details: string
}

export type EnquiryResult = { ok: true } | { ok: false; error: string }

const escapeHtml = (value: string) =>
  value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;')

const clean = (value: unknown, max: number) => (typeof value === 'string' ? value.trim().slice(0, max) : '')

export async function sendEnquiry(input: EnquiryInput): Promise<EnquiryResult> {
  const apiKey = process.env.RESEND_API_KEY
  if (!apiKey) return { ok: false, error: 'Email service is not configured yet. Please contact us on WhatsApp.' }

  const data = {
    name: clean(input.name, 100),
    email: clean(input.email, 200),
    phone: clean(input.phone, 30),
    brand: clean(input.brand, 150),
    service: clean(input.service, 60),
    details: clean(input.details, 5000),
  }

  const digits = data.phone.replace(/[^\d]/g, '')
  if (
    data.name.length < 2 ||
    !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(data.email) ||
    digits.length < 10 ||
    digits.length > 13 ||
    !data.service ||
    data.details.length < 15
  ) {
    return { ok: false, error: 'Please check the form fields and try again.' }
  }

  const rows: [string, string][] = [
    ['Name', data.name],
    ['Email', data.email],
    ['Phone', data.phone],
    ['Business / Brand', data.brand || '—'],
    ['Service', data.service],
  ]

  const html = `
    <div style="font-family:Arial,sans-serif;max-width:600px;color:#111">
      <h2 style="margin:0 0 16px">New Project Enquiry</h2>
      <table style="border-collapse:collapse;width:100%">
        ${rows
          .map(
            ([label, value]) =>
              `<tr><td style="padding:8px;border:1px solid #eee;font-weight:bold;width:160px">${label}</td><td style="padding:8px;border:1px solid #eee">${escapeHtml(value)}</td></tr>`,
          )
          .join('')}
      </table>
      <h3 style="margin:24px 0 8px">Project Details</h3>
      <p style="white-space:pre-wrap;line-height:1.6">${escapeHtml(data.details)}</p>
    </div>`

  const text = `${rows.map(([l, v]) => `${l}: ${v}`).join('\n')}\n\nProject Details:\n${data.details}`

  const resend = new Resend(apiKey)
  const { error } = await resend.emails.send({
    from: 'Your Next Web Studio <onboarding@resend.dev>',
    to: [RECIPIENT],
    replyTo: data.email,
    subject: `New enquiry: ${data.service} — ${data.name}`,
    html,
    text,
  })

  if (error) {
    console.error('Resend error:', error.message)
    return { ok: false, error: 'Could not send your enquiry right now. Please try again or message us on WhatsApp.' }
  }

  return { ok: true }
}
