import { Hero } from '@/components/home/hero'
import { Intro } from '@/components/home/intro'
import { ServicesPreview } from '@/components/home/services-preview'
import { FeaturedProjects } from '@/components/home/featured-projects'
import { Process } from '@/components/home/process'
import { Marquee } from '@/components/site/marquee'
import { CTASection } from '@/components/site/cta-section'

export default function HomePage() {
  return (
    <>
      <Hero />
      <Marquee />
      <Intro />
      <ServicesPreview />
      <FeaturedProjects />
      <Process />
      <CTASection
        eyebrow="Have a project in mind?"
        title={
          <>
            {"Let's build something your customers "}
            <span className="text-primary">remember.</span>
          </>
        }
        buttonLabel="Start a Project"
      />
    </>
  )
}
