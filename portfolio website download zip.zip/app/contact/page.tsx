import type { Metadata } from 'next'
import { ArrowUpRight, Mail, Phone } from 'lucide-react'
import { contact } from '@/lib/site'
import { PageHero } from '@/components/site/page-hero'
import { ContactForm } from '@/components/site/contact-form'
import { Reveal } from '@/components/site/reveal'
import { SiteButton } from '@/components/site/site-button'
import { InstagramIcon, WhatsAppIcon } from '@/components/site/brand-icons'

export const metadata: Metadata = {
  title: 'Contact',
  description:
    'Start a website, e-commerce or creative advertising project with Your Next Web Studio. Call, email, WhatsApp or send an enquiry.',
}

const details = [
  { label: 'Phone', value: contact.phoneDisplay, href: contact.phoneHref, icon: <Phone className="size-5" aria-hidden="true" /> },
  { label: 'Email', value: contact.email, href: contact.emailHref, icon: <Mail className="size-5" aria-hidden="true" /> },
  { label: 'Instagram', value: contact.instagramHandle, href: contact.instagramHref, icon: <InstagramIcon className="size-5" /> },
  { label: 'WhatsApp', value: '+91 6266801624', href: contact.whatsappHref, icon: <WhatsAppIcon className="size-5" /> },
]

export default function ContactPage() {
  return (
    <>
      <PageHero
        eyebrow="Contact"
        title={
          <>
            {"Let's Build Something "}
            <span className="text-primary">Great</span> Together.
          </>
        }
        description="Have a website, e-commerce store or creative advertising project in mind? Tell us what you're working on and let's discuss how we can bring it to life."
      />

      <section className="mx-auto max-w-7xl px-5 pb-20 sm:px-8 lg:pb-28" aria-label="Contact options">
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
          <div className="flex min-w-0 flex-col gap-4 lg:col-span-5">
            <ul className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-1">
              {details.map((d, i) => (
                <Reveal as="li" key={d.label} delay={i * 80}>
                  <a
                    href={d.href}
                    {...(d.href.startsWith('http') ? { target: '_blank', rel: 'noopener noreferrer' } : {})}
                    className="group flex items-center gap-4 rounded-2xl border border-white/[0.07] bg-card p-5 transition-all duration-300 hover:-translate-y-0.5 hover:border-primary/40"
                  >
                    <span className="flex size-12 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary transition-colors group-hover:bg-primary group-hover:text-primary-foreground">
                      {d.icon}
                    </span>
                    <span className="flex min-w-0 flex-1 flex-col">
                      <span className="text-xs uppercase tracking-[0.16em] text-muted-foreground">{d.label}</span>
                      <span className="break-all font-medium text-foreground">{d.value}</span>
                    </span>
                    <ArrowUpRight
                      className="size-4 shrink-0 text-muted-foreground transition-all group-hover:-translate-y-0.5 group-hover:translate-x-0.5 group-hover:text-primary"
                      aria-hidden="true"
                    />
                  </a>
                </Reveal>
              ))}
            </ul>

            <Reveal delay={200}>
              <div className="relative overflow-hidden rounded-3xl border border-white/[0.07] bg-[#111111] p-7">
                <div aria-hidden="true" className="absolute -right-16 -top-16 size-48 rounded-full bg-primary/20 blur-3xl" />
                <div className="relative flex flex-col gap-5">
                  <div className="flex flex-col gap-2">
                    <h2 className="text-2xl font-bold tracking-tight text-foreground">Prefer WhatsApp?</h2>
                    <p className="text-muted-foreground">Start a conversation directly.</p>
                  </div>
                  <SiteButton
                    href={contact.whatsappHref}
                    showArrow={false}
                    icon={<WhatsAppIcon className="size-4" />}
                    className="w-full sm:w-fit"
                  >
                    Chat on WhatsApp
                  </SiteButton>
                </div>
              </div>
            </Reveal>
          </div>

          <Reveal delay={120} className="lg:col-span-7">
            <ContactForm />
          </Reveal>
        </div>
      </section>
    </>
  )
}
