import type { Metadata } from 'next'
import Link from 'next/link'
import { Check, ArrowUpRight } from 'lucide-react'
import { services } from '@/lib/site'
import { PageHero } from '@/components/site/page-hero'
import { Reveal } from '@/components/site/reveal'
import { CTASection } from '@/components/site/cta-section'

export const metadata: Metadata = {
  title: 'Services',
  description:
    'Landing pages, business websites, Shopify stores, WordPress, portfolio websites, product ads, CGI ads, product videos and UGC content.',
}

export default function ServicesPage() {
  return (
    <>
      <PageHero
        eyebrow="Services"
        title={
          <>
            Services That Help Your Business <span className="text-primary">Stand Out</span> Online.
          </>
        }
        description="From websites to advertising creatives, we create digital experiences designed around your brand, audience and goals."
      >
        <nav aria-label="Jump to service" className="flex flex-wrap gap-2">
          {services.map((s) => (
            <Link
              key={s.id}
              href={`#${s.id}`}
              className="rounded-full border border-white/10 bg-white/[0.03] px-4 py-2 text-sm text-muted-foreground transition-colors hover:border-primary/60 hover:text-foreground"
            >
              {s.shortTitle}
            </Link>
          ))}
        </nav>
      </PageHero>

      <section className="mx-auto max-w-7xl px-5 pb-10 sm:px-8" aria-label="All services">
        <ul className="flex flex-col gap-4">
          {services.map((service) => {
            const Icon = service.icon
            return (
              <Reveal as="li" key={service.id}>
                <article
                  id={service.id}
                  className="group grid scroll-mt-28 gap-8 rounded-3xl border border-white/[0.07] bg-card p-6 transition-colors duration-500 hover:border-primary/40 sm:p-10 lg:grid-cols-12 lg:gap-10"
                >
                  <div className="flex items-start gap-5 lg:col-span-5">
                    <span className="font-display text-5xl font-extrabold leading-none text-white/10 transition-colors duration-300 group-hover:text-primary sm:text-6xl">
                      {service.number}
                    </span>
                    <div className="flex flex-col gap-4">
                      <span className="flex size-12 items-center justify-center rounded-2xl bg-primary/10 text-primary">
                        <Icon className="size-5" aria-hidden="true" />
                      </span>
                      <h2 className="text-2xl font-bold tracking-tight text-foreground sm:text-3xl">{service.title}</h2>
                    </div>
                  </div>
                  <div className="flex flex-col gap-6 lg:col-span-7">
                    <p className="text-lg leading-relaxed text-muted-foreground">{service.description}</p>
                    <ul className="grid gap-3 sm:grid-cols-2">
                      {service.features.map((f) => (
                        <li key={f} className="flex items-center gap-3 text-sm text-foreground">
                          <span className="flex size-5 shrink-0 items-center justify-center rounded-full bg-primary/15 text-primary">
                            <Check className="size-3" aria-hidden="true" />
                          </span>
                          {f}
                        </li>
                      ))}
                    </ul>
                    <Link
                      href="/contact"
                      className="inline-flex w-fit items-center gap-2 text-sm font-semibold text-foreground transition-colors hover:text-primary"
                    >
                      Enquire about {service.shortTitle.toLowerCase()}
                      <ArrowUpRight className="size-4" aria-hidden="true" />
                    </Link>
                  </div>
                </article>
              </Reveal>
            )
          })}
        </ul>
      </section>

      <CTASection
        eyebrow="Have a service in mind?"
        title={
          <>
            {"Let's discuss your "}
            <span className="text-primary">project.</span>
          </>
        }
        buttonLabel="Let's Talk"
      />
    </>
  )
}
