import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import { Inter, Manrope } from 'next/font/google'
import { Navbar } from '@/components/site/navbar'
import { Footer } from '@/components/site/footer'
import './globals.css'

const inter = Inter({ subsets: ['latin'], variable: '--font-inter', display: 'swap' })
const manrope = Manrope({ subsets: ['latin'], variable: '--font-manrope', display: 'swap' })

const title = 'Your Next Web Studio | Websites & Digital Creative Services'
const description =
  'Your Next Web Studio creates modern business websites, Shopify stores, WordPress websites, landing pages and creative product advertising content.'

export const metadata: Metadata = {
  title: {
    default: title,
    template: '%s | Your Next Web Studio',
  },
  description,
  keywords: [
    'web design',
    'website design',
    'business website',
    'Shopify website',
    'WordPress website',
    'landing page design',
    'portfolio website',
    'product ads',
    'CGI ads',
    'product advertising videos',
    'UGC content',
    'digital creative studio',
  ],
  generator: 'v0.app',
  openGraph: {
    title,
    description,
    siteName: 'Your Next Web Studio',
    type: 'website',
    locale: 'en_IN',
    images: [{ url: '/hero-visual.png', width: 1024, height: 1024, alt: 'Your Next Web Studio digital creative visual' }],
  },
  twitter: {
    card: 'summary_large_image',
    title,
    description,
    images: ['/hero-visual.png'],
  },
  icons: {
    icon: [
      { url: '/icon-light-32x32.png', media: '(prefers-color-scheme: light)' },
      { url: '/icon-dark-32x32.png', media: '(prefers-color-scheme: dark)' },
      { url: '/icon.svg', type: 'image/svg+xml' },
    ],
    apple: '/apple-icon.png',
  },
}

export const viewport: Viewport = {
  colorScheme: 'dark',
  themeColor: '#0B0B0B',
  width: 'device-width',
  initialScale: 1,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`${inter.variable} ${manrope.variable} bg-background`}>
      <body className="antialiased">
        <Navbar />
        <main id="main">{children}</main>
        <Footer />
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
