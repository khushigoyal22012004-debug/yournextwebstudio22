import type { Metadata } from 'next'
import { PageHero } from '@/components/site/page-hero'
import { ProjectGallery } from '@/components/projects/project-gallery'
import { CTASection } from '@/components/site/cta-section'

export const metadata: Metadata = {
  title: 'Projects',
  description: 'Explore website concepts and creative projects created by Your Next Web Studio.',
}

export default function ProjectsPage() {
  return (
    <>
      <PageHero
        eyebrow="Portfolio"
        title={
          <>
            Our <span className="text-primary">Projects</span>
          </>
        }
        description="Explore website concepts and creative projects created by Your Next Web Studio."
      />

      <section className="mx-auto max-w-7xl px-5 pb-10 sm:px-8" aria-label="Project gallery">
        <ProjectGallery />
      </section>

      <CTASection
        eyebrow="Like what you see?"
        title={
          <>
            {"Let's create your "}
            <span className="text-primary">next website.</span>
          </>
        }
        buttonLabel="Start a Project"
      />
    </>
  )
}
